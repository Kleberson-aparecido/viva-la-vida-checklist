# Viva La Vida 24 Horas — Checklist de Estoque

Sistema web estático para contagem de estoque da adega.

## Publicar pelo GitHub Pages
1. Crie um repositório no GitHub (por exemplo `viva-la-vida-checklist`).
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde a publicação e abra o endereço mostrado pelo GitHub Pages.

## Recursos
- 163 produtos organizados por categoria.
- Quantidades de unidades fechadas, abertas e avulsas.
- Estoque mínimo editável por produto.
- Estados separados: Não contado, Estoque OK, Estoque baixo e Em falta.
- Salva dados no armazenamento local do navegador deste aparelho.
- Exportação para PDF via diálogo de impressão, PNG e CSV.

## Importante
- Todos os produtos começam com quantidades 0 e estado “Não contado”.
- Para confirmar uma contagem, informe as quantidades e altere o seletor para “Contado”.
- O sistema não sincroniza automaticamente entre aparelhos; cada dispositivo tem seus próprios dados locais.
- A exportação PNG utiliza html2canvas carregado de CDN, por isso precisa de internet.
